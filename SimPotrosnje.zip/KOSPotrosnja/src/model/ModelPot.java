package model;

import java.io.Serializable;

public class ModelPot implements Serializable {

	private double snagaTrosilo1;
	private double snagaTrosilo2;
	private double snagaTrosilo3;
	private double snagaTrosilo4;
	private double rezTrosilo1;
	private double rezTrosilo2;
	private double rezTrosilo3;
	private double rezTrosilo4;
	private double rezUkupno;
	private int vrijemeSim;
	
	public double getSnagaTrosilo1() {
		return snagaTrosilo1;
	}
	public void setSnagaTrosilo1(double snagaTrosilo1) {
		this.snagaTrosilo1 = snagaTrosilo1;
	}
	public double getSnagaTrosilo2() {
		return snagaTrosilo2;
	}
	public void setSnagaTrosilo2(double snagaTrosilo2) {
		this.snagaTrosilo2 = snagaTrosilo2;
	}
	public double getSnagaTrosilo3() {
		return snagaTrosilo3;
	}
	public void setSnagaTrosilo3(double snagaTrosilo3) {
		this.snagaTrosilo3 = snagaTrosilo3;
	}
	public double getSnagaTrosilo4() {
		return snagaTrosilo4;
	}
	public void setSnagaTrosilo4(double snagaTrosilo4) {
		this.snagaTrosilo4 = snagaTrosilo4;
	}
	public double getRezTrosilo1() {
		return rezTrosilo1;
	}
	public void setRezTrosilo1(double rezTrosilo1) {
		this.rezTrosilo1 = rezTrosilo1;
	}
	public double getRezTrosilo2() {
		return rezTrosilo2;
	}
	public void setRezTrosilo2(double rezTrosilo2) {
		this.rezTrosilo2 = rezTrosilo2;
	}
	public double getRezTrosilo3() {
		return rezTrosilo3;
	}
	public void setRezTrosilo3(double rezTrosilo3) {
		this.rezTrosilo3 = rezTrosilo3;
	}
	public double getRezTrosilo4() {
		return rezTrosilo4;
	}
	public void setRezTrosilo4(double rezTrosilo4) {
		this.rezTrosilo4 = rezTrosilo4;
	}
	public double getRezUkupno() {
		return rezUkupno;
	}
	public void setRezUkupno(double rezUkupno) {
		this.rezUkupno = rezUkupno;
	}
	public int getVrijemeSim() {
		return vrijemeSim;
	}
	public void setVrijemeSim(int vrijemeSim) {
		this.vrijemeSim = vrijemeSim;
	}
}
